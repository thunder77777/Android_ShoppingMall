package com.example.yikeshop.type.fragment;

import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.TextView;

import com.example.yikeshop.base.BaseFragment;

/**
 * 分类fragment
 */
public class TypeFragment extends BaseFragment {
    private static final String TAG = "孙华团";
    private TextView textview;
    @Override
    public View initView() {
        Log.e(TAG,"分类的Fragment的UI被初始化了");
        textview = new TextView(mContext);
        textview.setGravity(Gravity.CENTER);
        textview.setTextSize(25);
        return textview;
    }

    @Override
    public void initData() {
        super.initData();
        Log.e(TAG,"分类的Fragment的UI被初始化了");
        textview.setText("分类内容");
    }
}
