package com.example.yikeshop.app;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.widget.RadioGroup;

import com.example.yikeshop.R;
import com.example.yikeshop.base.BaseFragment;
import com.example.yikeshop.community.fragment.CommunityFragment;
import com.example.yikeshop.home.fragment.HomeFragment;
import com.example.yikeshop.shoppingcart.fragment.ShoppingCartFragment;
import com.example.yikeshop.type.fragment.TypeFragment;
import com.example.yikeshop.user.fragment.UserFragment;

import java.util.ArrayList;

public class MmainActivity extends FragmentActivity {

    private RadioGroup rg_main;
    /**
     * 装多个Fragment的集合
     */
    private ArrayList<BaseFragment> fragments;
    private int position = 0;
    /**
     * 缓存的fragment
     */
    private Fragment tempFragemnt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mmain);
        rg_main = (RadioGroup) findViewById(R.id.rg_main);
        initFragment();
        //设置radioGroup监听
        initListener();
    }
    public void initListener()
    {
        rg_main.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int checkedid) {
                switch(checkedid)
                {
                    case R.id.rb_home:
                        position = 0;
                        break;
                    case R.id.rb_type:
                        position = 1;
                        break;
                    case R.id.rb_community:
                        position = 2;
                        break;
                    case R.id.rb_cart:
                        position = 3;
                        break;
                    case R.id.rb_user:
                        position = 4;
                        break;
                    default:
                        position = 0;
                        break;
                }
                //根据位置取不同的fragment
                BaseFragment baseFragment = getFragment(position);
                /**
                 * 第一个参数：上次显示的
                 * 第二个：当前要显示的
                 */
                switchFragment(tempFragemnt,baseFragment);
            }
        });
        rg_main.check(R.id.rb_home);
    }
    /**
     * 按照顺序
     */
    private void initFragment() {
        fragments = new ArrayList<>();
        fragments.add(new HomeFragment());
        fragments.add(new TypeFragment());
        fragments.add(new CommunityFragment());
        fragments.add(new ShoppingCartFragment());
        fragments.add(new UserFragment());
    }

    private BaseFragment getFragment(int position)
    {
        if (fragments != null && fragments.size() > 0) {
            BaseFragment baseFragment = fragments.get(position);
            return baseFragment;
        }
        return null;
    }

    /**
     * 切换fragment
     * @param fromFragment
     * @param nextFragment
     */
    private void switchFragment(Fragment fromFragment, BaseFragment
            nextFragment) {
        if (tempFragemnt != nextFragment) {
            tempFragemnt = nextFragment;
            if (nextFragment != null) {
                FragmentTransaction transaction =
                        getSupportFragmentManager().beginTransaction();
                //判断 nextFragment 是否添加
                if (!nextFragment.isAdded()) {
                    //隐藏当前 Fragment
                    if (fromFragment != null) {
                        transaction.hide(fromFragment);
                    }
                    transaction.add(R.id.frameLayout, nextFragment).commit();
                } else {
                    //隐藏当前 Fragment
                    if (fromFragment != null) {
                        transaction.hide(fromFragment);
                    }
                    transaction.show(nextFragment).commit();
                }
            }
        }
    }
}