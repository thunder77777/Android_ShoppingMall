package com.example.yikeshop.community.fragment;

import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.TextView;

import com.example.yikeshop.base.BaseFragment;

/**
 * 发现fragment
 */
public class CommunityFragment extends BaseFragment {
    private static final String TAG = "孙华团";
    private TextView textview;
    @Override
    public View initView() {
        Log.e(TAG,"发现的Fragment的UI被初始化了");
        textview = new TextView(mContext);
        textview.setGravity(Gravity.CENTER);
        textview.setTextSize(25);
        return textview;
    }

    @Override
    public void initData() {
        super.initData();
        Log.e(TAG,"发现的Fragment的UI被初始化了");
        textview.setText("发现内容");
    }
}
