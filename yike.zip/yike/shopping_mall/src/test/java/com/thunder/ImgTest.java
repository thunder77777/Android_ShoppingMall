package com.thunder;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.thunder.controller.ShopController;
import com.thunder.mapper.OrderDetailMapper;
import com.thunder.mapper.OrderMapper;
import com.thunder.pojo.*;
import com.thunder.pojo.parameter.CommodityParameter;
import com.thunder.pojo.parameter.PurchaseParameter;
import com.thunder.util.FileUtils;
import com.thunder.util.JSONUtils;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.PropertySource;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@SpringBootTest
@PropertySource("classpath:yike.properties")
public class ImgTest {
    @Value("${userImgPath}")
    private String path;

    @Autowired
    private OrderDetailMapper orderDetailMapper;

    @Autowired
    private OrderMapper orderMapper;

    @Test
    void userUITest() throws IOException {
        File file = new File("E:\\个人\\移动应用开发\\实验\\img\\test.png");
        MultipartFile mulFile = new MockMultipartFile(
                "test.png", //文件名
                "test.png", //originalName 相当于上传文件在客户机上的文件名
                "png", //文件类型
                new FileInputStream(file) //文件流
        );

        String fileName = FileUtils.getFileName(mulFile, 10);
        String filePath = FileUtils.getFilePath_commodity(fileName);
        System.out.println("fileType: " + FileUtils.getContentType(fileName));
        System.out.println("fileName: " + fileName);
        System.out.println("filePath: " + filePath);
        System.out.println("checkSize: " + FileUtils.checkSize(mulFile));
        System.out.println("checkType: " + FileUtils.checkType(mulFile));
    }

    @Test
    void imgUploadTest() throws IOException {
        File file = new File("E:\\个人\\移动应用开发\\实验\\img\\test.png");
        MultipartFile mulFile = new MockMultipartFile(
                "test.png", //文件名
                "test.png", //originalName 相当于上传文件在客户机上的文件名
                "png", //文件类型
                new FileInputStream(file) //文件流
        );

        ShopController sc = new ShopController();
        sc.uploadImg(mulFile, 1);
    }

    @Test
    void listJsonTest() throws JsonProcessingException {
        Commodity c1 = new Commodity();
        Commodity c2 = new Commodity();
        Commodity c3 = new Commodity();
        List<Commodity> list = new ArrayList<>();
        list.add(c1);
        list.add(c2);
        list.add(c3);

        System.out.println(JSONUtils
                .toJSON(Result.setSuccess(Result.ResultCode.SUCCESS, list)));
    }

    @Test
    void mapJsonTest() throws JsonProcessingException {
        CommodityDetail cd = new CommodityDetail();
        Shop s = new Shop();
        boolean isSub = false;
        boolean isColl = false;
        Map<String, Object> data = new HashMap<>();
        data.put("cd", cd);
        data.put("shop", s);
        data.put("isSub", isSub);
        data.put("isColl", isColl);

        System.out.println(JSONUtils.toJSON(Result.setSuccess(Result.ResultCode.SUCCESS,
                data)));
    }

    @Test
    void cdTest() throws JsonProcessingException {
        CommodityDetail cd = new CommodityDetail();
        System.out.println(JSONUtils.toJSON(cd));
    }

    @Test
    void shopTest() throws JsonProcessingException {
        Shop s = new Shop();
        System.out.println(JSONUtils.toJSON(s));
    }

    @Test
    void pojoTest() throws JsonProcessingException {
        PurchaseParameter pp = new PurchaseParameter();
        Order o = new Order();
        OrderDetail od = new OrderDetail();
        CommodityParameter cp = new CommodityParameter();
        ShoppingCart sc = new ShoppingCart();
        ShopSubscription ss = new ShopSubscription();
        //System.out.println(JSONUtils.toJSON(pp));
        //System.out.println(JSONUtils.toJSON(o));
        //System.out.println(JSONUtils.toJSON(od));
        //System.out.println(JSONUtils.toJSON(cp));
        //System.out.println(JSONUtils.toJSON(sc));
        System.out.println(JSONUtils.toJSON(ss));
    }

    @Test
    void orderListTest() throws JsonProcessingException {
        Order o1 = new Order();
        Order o2 = new Order();
        Order o3 = new Order();
        List<Order> data = new ArrayList<>();
        data.add(o1);
        data.add(o2);
        data.add(o3);

        System.out.println(JSONUtils
                .toJSON(Result.setSuccess(Result.ResultCode.SUCCESS, data)));
    }

    @Test
    void enterShopTest() throws JsonProcessingException {
        Map<String, Object> data = new HashMap<>();
        Commodity c1 = new Commodity();
        Commodity c2 = new Commodity();
        Commodity c3 = new Commodity();
        List<Commodity> commodities = new ArrayList<>();
        commodities.add(c1);
        commodities.add(c2);
        commodities.add(c3);
        Shop shop = new Shop();
        boolean isSub = true;

        data.put("commodities", commodities);
        data.put("shop", shop);
        data.put("isSub", isSub);
        System.out.println(JSONUtils
                .toJSON(Result.setSuccess(Result.ResultCode.SUCCESS, data)));
    }

    @Test
    void userTest() throws JsonProcessingException {
        User user = new User();
        user.setUid(100);
        user.setBirthday(LocalDate.now());
        user.setName("雷神");
        user.setSignature("我就是神，哈哈哈！！！");
        user.setSex(1);

        System.out.println(JSONUtils.toJSON(user));
    }

    @Test
    void test03() throws JsonProcessingException {
        LocalDate localDate = LocalDate.now();
        System.out.println(JSONUtils.toJSON(localDate));

        System.out.println(JSONUtils.toObject("[2022,5,22]", LocalDate.class));
    }

    @Test
    void delOrderDetails(){
        LambdaQueryWrapper<Order> lqw = new LambdaQueryWrapper<>();
        LambdaUpdateWrapper<OrderDetail> luw = new LambdaUpdateWrapper<>();
        lqw.eq(Order::getUid, 100);
        List<Order> orders = orderMapper.selectList(lqw);
        for (Order order : orders) {
            luw.eq(OrderDetail::getOid, order.getOid());
            orderDetailMapper.delete(luw);
            luw.clear();
        }
    }

    @Test
    void delOrder(){
        int uid = 100;
        LambdaQueryWrapper<Order> lqw_order = new LambdaQueryWrapper<>();
        LambdaUpdateWrapper<OrderDetail> luw_od = new LambdaUpdateWrapper<>();
        LambdaUpdateWrapper<Order> luw_o = new LambdaUpdateWrapper<>();
        lqw_order.eq(Order::getUid, uid);

        List<Order> orders = orderMapper.selectList(lqw_order);
        for (Order order : orders) {
            luw_od.eq(OrderDetail::getOid, order.getOid());
            orderDetailMapper.delete(luw_od);
            luw_od.clear();
        }
        luw_o.eq(Order::getUid, uid);
        orderMapper.delete(luw_o);
    }
}
