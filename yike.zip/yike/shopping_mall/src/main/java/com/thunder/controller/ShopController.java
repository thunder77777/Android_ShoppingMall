package com.thunder.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.thunder.pojo.*;
import com.thunder.pojo.parameter.CommodityParameter;
import com.thunder.service.ICommodityService;
import com.thunder.service.IShopService;
import com.thunder.service.IUserService;
import com.thunder.util.FileUtils;
import com.thunder.util.JSONUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@RestController
@ResponseBody
@Transactional
@RequestMapping("/shops")
public class ShopController {
    @Value("${commodityKey}")
    private String commodityKey;

    @Autowired
    private IShopService shopService;

    @Autowired
    private ICommodityService commodityService;

    @Autowired
    private IUserService userService;

    @Autowired
    private StringRedisTemplate redisTemplate;

    /**
     * 开店铺
     *
     * @param uid
     * @param shopTitle
     * @return flag
     */
    @PostMapping("/openshop")
    public Result openShop(@RequestParam int uid, @RequestParam String shopTitle) {
        if (shopTitle != null && userService.getById(uid) != null) {
            LambdaQueryWrapper<Shop> lqw = new LambdaQueryWrapper<>();
            lqw.eq(Shop::getShopTitle, shopTitle);
            if (shopService.getOne(lqw) == null) {
                Shop shop = new Shop();
                shop.setBuid(uid);
                shop.setShopTitle(shopTitle);
                if (shopService.save(shop)) {
                    return Result.setSuccess(Result.ResultCode.SUCCESS, null);
                }
                return Result.setError(Result.ResultCode.DATABASE_STORAGE_ERROR);
            }
            return Result.setError(Result.ResultCode.SHOP_TITLE_DUPLICATED);
        }
        return Result.setError(Result.ResultCode.PARAM_ERROR);
    }

    /**
     * 添加商品
     *
     * @param cp
     * @return flag
     */
    @PostMapping("/addcomm")
    public Result addCommodity(@RequestBody CommodityParameter cp) {
        if (cp == null) {
            return Result.setError(Result.ResultCode.PARAM_ERROR);
        }
        LambdaQueryWrapper<Shop> lqw = new LambdaQueryWrapper<>();
        lqw.eq(Shop::getBuid, cp.getUid())
                .eq(Shop::getSid, cp.getSid());
        if (shopService.getOne(lqw) != null) {
            Commodity commodity = new Commodity();
            commodity.setCommodityTitle(cp.getCommodityTitle());
            commodity.setCommodityPrice(cp.getCommodityPrice());
            commodity.setSid(cp.getSid());
            commodity.setSid(cp.getSid());
            if (!commodityService.save(commodity)) {
                return Result.setError(Result.ResultCode.DATABASE_STORAGE_ERROR);
            }

            CommodityDetail cd = new CommodityDetail();
            cd.setCid(commodity.getCid());
            cd.setStock(cp.getStock());
            if (!commodityService.insertCD(cd)) {
                return Result.setError(Result.ResultCode.DATABASE_STORAGE_ERROR);
            }
            return Result.setSuccess(Result.ResultCode.SUCCESS, null);
        }
        return Result.setError(Result.ResultCode.SHOP_NOTFOUND);
    }

    /**
     * 下架商品
     *
     * @param cid
     * @return flag
     */
    @PutMapping("/delcomm")
    public Result delCommodity(@RequestParam int cid) {
        LambdaQueryWrapper<Commodity> lqw = new LambdaQueryWrapper<>();
        lqw.eq(Commodity::getCid, cid);
        if (commodityService.getOne(lqw) == null) {
            return Result.setError(Result.ResultCode.COMMODITY_NOTFOUND);
        }

        LambdaUpdateWrapper<Commodity> luw = new LambdaUpdateWrapper<>();
        luw.eq(Commodity::getCid, cid)
                .set(Commodity::getStatus, 2);
        if (commodityService.update(luw)) {
            return Result.setSuccess(Result.ResultCode.SUCCESS, null);
        }
        return Result.setError(Result.ResultCode.DATABASE_STORAGE_ERROR);
    }

    /**
     * 关闭店铺
     *
     * @param sid
     * @return flag
     */
    @PutMapping("/closeshop")
    public Result closeShop(@RequestParam int sid) {
        LambdaUpdateWrapper<Shop> luw_s = new LambdaUpdateWrapper<>();
        luw_s.eq(Shop::getSid, sid)
                .set(Shop::getStatus, 1);
        if (shopService.update(luw_s)) {
            LambdaQueryWrapper<Commodity> lqw = new LambdaQueryWrapper<>();
            lqw.eq(Commodity::getSid, sid);
            List<Commodity> cList = commodityService.list(lqw);
            for (Commodity commodity : cList) {
                LambdaUpdateWrapper<Commodity> luw_c = new LambdaUpdateWrapper<>();
                luw_c.eq(Commodity::getCid, commodity.getCid())
                        .set(Commodity::getStatus, 2);
                commodityService.update(luw_c);
            }
            return Result.setSuccess(Result.ResultCode.SUCCESS, null);
        }
        return Result.setError(Result.ResultCode.SHOP_NOTFOUND);
    }

    /**
     * 进入店铺
     *
     * @param uid
     * @param sid
     * @return map<string, object> list<commodity>、shop、isSub（是否订阅）
     */
    @GetMapping("/entershop/{uid}/{sid}")
    public Result enterShop(@PathVariable int uid, @PathVariable int sid)
            throws JsonProcessingException {
        Shop shop = shopService.selectById(sid);
        if (shop != null) {
            Map<String, Object> data = new HashMap<>();
            //是否订阅
            LambdaQueryWrapper<ShopSubscription> lqw_s = new LambdaQueryWrapper<>();
            lqw_s.eq(ShopSubscription::getUid, uid)
                    .eq(ShopSubscription::getSid, sid);
            boolean isSub = shopService.isSub(lqw_s);

            //获取店铺商品表
            LambdaQueryWrapper<Commodity> lqw_c = new LambdaQueryWrapper<>();
            lqw_c.eq(Commodity::getSid, sid);
            List<Commodity> commodities = commodityService.list(lqw_c);

            data.put("commodities", commodities);
            data.put("shop", shop);
            data.put("isSub", isSub);
            return Result.setSuccess(Result.ResultCode.SUCCESS, data);
        }
        return Result.setError(Result.ResultCode.INFO_NOTFOUND);
    }

    /**
     * 订阅店铺
     *
     * @param uid
     * @param sid
     * @return flag
     */
    @PostMapping("/shopsub")
    public Result shopSub(@RequestParam int uid, @RequestParam int sid) {
        if (userService.getById(uid) != null) {
            Shop shop = shopService.getById(sid);
            if (shop != null) {
                ShopSubscription ss = new ShopSubscription();
                ss.setUid(uid);
                ss.setSid(sid);
                ss.setShopTitle(shop.getShopTitle());
                if (shopService.insertSS(ss)) {
                    return Result.setSuccess(Result.ResultCode.SUCCESS, null);
                }
                return Result.setError(Result.ResultCode.DATABASE_STORAGE_ERROR);
            }
            return Result.setError(Result.ResultCode.SHOP_NOTFOUND);
        }
        return Result.setError(Result.ResultCode.USER_NOTFOUND);
    }

    /**
     * 查看订阅的店铺
     *
     * @param uid
     * @param pageNum
     * @param count
     * @return List<Shop>
     */
    @GetMapping("/getss/{uid}/{pageNum}/{count}")
    public Result getSS(@PathVariable int uid,
                        @PathVariable int pageNum, @PathVariable int count) {
        if (pageNum < 0 || count <= 0) {
            return Result.setError(Result.ResultCode.PARAM_ERROR);
        }

        IPage<ShopSubscription> page = new Page<>(pageNum, count);
        LambdaQueryWrapper<ShopSubscription> lqw = new LambdaQueryWrapper<>();
        lqw.eq(ShopSubscription::getUid, uid);
        shopService.getSSPage(page, lqw);
        return Result.setSuccess(Result.ResultCode.SUCCESS, page.getRecords());
    }

    /**
     * 上传商品主图
     *
     * @param file
     * @param cid
     * @return flag
     * @throws IOException
     */
    @PostMapping("/uploadimg")
    public Result uploadImg(@RequestParam MultipartFile file, @RequestParam int cid)
            throws IOException {
        if (file != null) {
            if (FileUtils.checkType(file)) {
                if (FileUtils.checkSize(file)) {
                    Commodity commodity = commodityService.getById(cid);
                    if (commodity != null) {
                        //原来的主图
                        String img_old = commodity.getCommodityImg();

                        String fileName = FileUtils.getFileName(file, cid);
                        String filePath = FileUtils.getFilePath_commodity(fileName);
                        log.error("fileName: " + fileName + ", filePath: " + filePath);
                        file.transferTo(new File(filePath));
                        LambdaUpdateWrapper<Commodity> luw = new LambdaUpdateWrapper<>();
                        luw.eq(Commodity::getCid, cid)
                                .set(Commodity::getCommodityImg, fileName);

                        //更新数据库前删除redis中的值
                        redisTemplate.delete(commodityKey + commodity.getCid());
                        if (commodityService.update(luw)) {
                            commodity.setCommodityImg(fileName);
                            //更新数据库后再次删除redis中的值
                            redisTemplate.delete(commodityKey + commodity.getCid());
                            //更新成功后删除重新设置redis值
                            redisTemplate.opsForValue()
                                    .set(commodityKey + commodity.getCid(),
                                            JSONUtils.toJSON(commodity));
                            //上传成功则删除原来的头像
                            if (img_old != null){
                                File delFile =
                                        new File(FileUtils.getFilePath_commodity(img_old));
                                if (delFile.exists()){
                                    delFile.delete();
                                }
                            }
                            return Result.setSuccess(Result.ResultCode.SUCCESS, null);
                        }
                        return Result.setError(Result.ResultCode.DATABASE_STORAGE_ERROR);
                    }
                    return Result.setError(Result.ResultCode.USER_NOTFOUND);
                }
                return Result.setError(Result.ResultCode.IMG_SIZE_ERROR);
            }
            return Result.setError(Result.ResultCode.IMG_TYPE_ERROR);
        }
        return Result.setError(Result.ResultCode.PARAM_ERROR);
    }
}
