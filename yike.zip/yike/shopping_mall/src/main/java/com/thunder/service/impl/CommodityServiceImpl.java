package com.thunder.service.impl;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.thunder.mapper.CommodityCollectionMapper;
import com.thunder.mapper.CommodityDetailMapper;
import com.thunder.mapper.CommodityMapper;
import com.thunder.pojo.Commodity;
import com.thunder.pojo.CommodityCollection;
import com.thunder.pojo.CommodityDetail;
import com.thunder.service.ICommodityService;
import com.thunder.util.JSONUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

@Service
public class CommodityServiceImpl extends ServiceImpl<CommodityMapper, Commodity>
        implements ICommodityService {
    @Autowired
    private CommodityMapper commodityMapper;

    @Autowired
    private CommodityDetailMapper cdMapper;

    @Autowired
    private CommodityCollectionMapper commodityCollectionMapper;

    @Autowired
    private StringRedisTemplate redisTemplate;

    @Value("${commodityKey}")
    private String commodityKey;

    @Value("${commodityDetailKey}")
    private String commodityDetailKey;

    @Override
    public Commodity selectById(int cid) throws JsonProcessingException {
        String commodity_json = redisTemplate.opsForValue().get(commodityKey + cid);
        if (commodity_json != null) {
            return (Commodity) JSONUtils.toObject(commodity_json, Commodity.class);
        }

        //redis中不存在店铺对象，则从数据库中查找并放入redis中
        Commodity commodity = commodityMapper.selectById(cid);
        redisTemplate.opsForValue().set(commodityKey + cid, JSONUtils.toJSON(commodity));
        return commodity;
    }

    @Override
    public boolean collect(CommodityCollection commodityCollection) {
        return commodityCollectionMapper.insert(commodityCollection) > 0;
    }

    @Override
    public IPage<CommodityCollection> getCCPage(IPage<CommodityCollection> page,
                                                Wrapper<CommodityCollection> queryWrapper) {
        return commodityCollectionMapper.selectPage(page, queryWrapper);
    }

    /**
     * 获取商品详情对象
     *
     * @param cid
     * @return
     */
    @Override
    public CommodityDetail selectCDById(int cid) throws JsonProcessingException {
        String cd_json = redisTemplate.opsForValue().get(commodityDetailKey + cid);
        if (cd_json != null) {
            return (CommodityDetail) JSONUtils.toObject(cd_json, CommodityDetail.class);
        }

        //redis中不存在店铺对象，则从数据库中查找并放入redis中
        CommodityDetail cd = cdMapper.selectById(cid);
        redisTemplate.opsForValue().set(commodityDetailKey + cid,
                JSONUtils.toJSON(cd));
        return cd;
    }

    @Override
    public boolean isColl(Wrapper<CommodityCollection> queryWrapper) {
        return commodityCollectionMapper.selectOne(queryWrapper) != null;
    }

    @Override
    public boolean insertCD(CommodityDetail cd) {
        return cdMapper.insert(cd) > 0;
    }
}
