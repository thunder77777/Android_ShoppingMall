package com.thunder.config.handler;

import com.fasterxml.jackson.core.JsonParseException;
import com.thunder.pojo.Result;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;

@Slf4j
@RestControllerAdvice
public class DefaultExceptionHandler {
    /**缺少必要的参数*/
    @ExceptionHandler(value = MissingServletRequestParameterException.class)
    public Result missingParameterHandler(HttpServletRequest request, MissingServletRequestParameterException e) {
        this.logError(request,e);
        return Result.setError(Result.ResultCode.PARAM_MISSING);
    }

    /**参数类型不匹配*/
    @ExceptionHandler(value = MethodArgumentTypeMismatchException.class)
    public Result methodArgumentTypeMismatchException(HttpServletRequest request,MethodArgumentTypeMismatchException e) {
        this.logError(request,e);
        return Result.setError(Result.ResultCode.PARAM_TYPE_MISMATCH);
    }

    /**不支持的请求方法*/
    @ExceptionHandler(value = HttpRequestMethodNotSupportedException.class)
    public Result httpRequestMethodNotSupportedException(HttpServletRequest request,HttpRequestMethodNotSupportedException e) {
        this.logError(request,e);
        return Result.setError(Result.ResultCode.UNKNOWN_REASON);
    }

    /**参数错误*/
    @ExceptionHandler(value = IllegalArgumentException.class)
    public Result illegalArgumentException(HttpServletRequest request,IllegalArgumentException e) {
        this.logError(request,e);
        return Result.setError(Result.ResultCode.PARAM_ERROR);
    }

    /**图片上传错误*/
    @ExceptionHandler(value = IOException.class)
    public Result IOException(HttpServletRequest request,IllegalArgumentException e) {
        this.logError(request,e);
        return Result.setError(Result.ResultCode.IMG_UPLOAD_ERROR);
    }

    /**json解析异常*/
    @ExceptionHandler(value = JsonParseException.class)
    public Result illegalArgumentException(HttpServletRequest request,JsonParseException e) {
        this.logError(request,e);
        return Result.setError(Result.ResultCode.JSON_PARSE_ERROR);
    }

    /**其他异常统一处理*/
    @ExceptionHandler(value = Exception.class)
    public Result exception(HttpServletRequest request, Exception e) {
        this.logError(request,e);
        return Result.setError(Result.ResultCode.UNKNOWN_REASON);
    }

    /**
     * 记录错误日志
     */
    private void logError(HttpServletRequest request, Exception e){
        log.error("path:{}, queryParam:{}, errorMessage:{}", request.getRequestURI()
                , request.getQueryString(), e.getMessage(), e);
    }
}
