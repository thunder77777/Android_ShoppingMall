package com.thunder.util;

import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.util.UUID;

@Slf4j
@Component
@PropertySource("classpath:yike.properties")
public class FileUtils {
    private static String userImgPath;

    private static String commodityImgPath;

    private static double maxImgSize;

    @Value("${userImgPath}")
    public void setUserImgPath(String userImgPath) {
        FileUtils.userImgPath = userImgPath;
    }

    @Value("${commodityImgPath}")
    public void setCommodityImgPath(String commodityImgPath){
        FileUtils.commodityImgPath = commodityImgPath;
    }

    @Value("${maxImgSize}")
    public void setMaxImgSize(double maxImgSize) {
        FileUtils.maxImgSize = maxImgSize;
    }

    private static final String[] fileTypes = {"jpg", "png", "jpeg", "bmp"};

    public static boolean checkType(@NonNull MultipartFile file) {
        String fileType = getSuffix(file.getContentType());
        log.error("fileType: " + fileType);
        for (String type : fileTypes) {
            if (type.equals(fileType)) {
                return true;
            }
        }
        return false;
    }

    public static boolean checkSize(MultipartFile file) {
        double imgSize = (double) file.getSize() / 1024 / 1024;
        return imgSize < maxImgSize;
    }

    public static String getFilePath(@NonNull MultipartFile file, int id) {
        String fileName = getFileName(file, id);
        return userImgPath + fileName;
    }

    public static String getSuffix(String type){
        return type.substring(type.lastIndexOf("/") + 1);
    }

    public static String getContentType(@NonNull MultipartFile file) {
        return file.getContentType();
    }

    public static String getContentType(@NonNull String fileName) {
        String type = fileName.substring(fileName.lastIndexOf(".") + 1);
        return "image/" + type;
    }

    public static String getFilePath_user(@NonNull String fileName) {
        return userImgPath + fileName;
    }

    public static String getFilePath_commodity(@NonNull String fileName){
        return commodityImgPath + fileName;
    }

    public static String getFileName(@NonNull MultipartFile file, int id) {
        String fileType = getSuffix(file.getContentType());
        return UUID.randomUUID().toString() + id + "." + fileType;
    }
}
