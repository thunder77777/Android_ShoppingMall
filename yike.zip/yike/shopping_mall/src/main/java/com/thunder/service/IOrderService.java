package com.thunder.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.thunder.pojo.Order;
import com.thunder.pojo.OrderDetail;

public interface IOrderService extends IService<Order> {
    boolean save_orderDetail(OrderDetail orderDetail);

    OrderDetail getOneDetail(int oid);
}
