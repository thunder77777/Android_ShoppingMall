package com.thunder.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.thunder.pojo.ShopSubscription;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ShopSubscriptionMapper extends BaseMapper<ShopSubscription> {
}
