package com.thunder.pojo.parameter;

import lombok.Data;

/**
 * 下单参数
 */
@Data
public class PurchaseParameter {
    private int uid;
    private int cid;
    private int sid;
    private int payment;
    private int quantity;
}
