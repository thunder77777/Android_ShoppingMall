package com.thunder.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.thunder.pojo.*;
import com.thunder.service.ICommodityService;
import com.thunder.service.IShopService;
import com.thunder.util.FileUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;

@RestController
@Slf4j
@ResponseBody
@Transactional
@RequestMapping("/commodities")
public class CommodityController {

    @Autowired
    private ICommodityService commodityService;

    @Autowired
    private IShopService shopService;

    /**
     * 收藏商品
     *
     * @param uid
     * @param cid
     * @return
     * @throws JsonProcessingException
     */
    @PostMapping("/collect")
    public Result collect(@RequestParam int uid, @RequestParam int cid)
            throws JsonProcessingException {
        Commodity commodity = commodityService.selectById(cid);
        CommodityCollection commodityCollection = new CommodityCollection();
        commodityCollection.setCid(commodity.getCid());
        commodityCollection.setCommodityImg(commodity.getCommodityImg());
        commodityCollection.setCommodityPrice(commodity.getCommodityPrice());
        commodityCollection.setCommodityTitle(commodity.getCommodityTitle());
        commodityCollection.setUid(uid);

        if (commodityService.collect(commodityCollection)) {
            return Result.setSuccess(Result.ResultCode.SUCCESS, null);
        }
        return Result.setError(Result.ResultCode.DATABASE_STORAGE_ERROR);
    }

    /**
     * 浏览商品
     *
     * @param pageNum
     * @param count
     * @return List<Commodity>
     */
    @GetMapping("/getc/{pageNum}/{count}")
    public Result getC(@PathVariable int pageNum, @PathVariable int count) {
        if (pageNum < 0 || count <= 0) {
            return Result.setError(Result.ResultCode.PARAM_ERROR);
        }
        IPage<Commodity> page = new Page<>(pageNum, count);
        LambdaQueryWrapper<Commodity> lqw = new LambdaQueryWrapper<>();
        lqw.eq(Commodity::getStatus, 0);
        commodityService.page(page, lqw);
        return Result.setSuccess(Result.ResultCode.SUCCESS, page.getRecords());
    }

    /**
     * 查看收藏的商品
     *
     * @param uid
     * @param pageNum
     * @param count
     * @return List<Commodity>
     */
    @GetMapping("/getcollection/{uid}/{pageNum}/{count}")
    public Result getCollection(@PathVariable int uid,
                                @PathVariable int pageNum, @PathVariable int count) {
        if (pageNum < 0 || count <= 0) {
            return Result.setError(Result.ResultCode.PARAM_ERROR);
        }

        IPage<CommodityCollection> page = new Page<>(pageNum, count);
        LambdaQueryWrapper<CommodityCollection> lqw = new LambdaQueryWrapper<>();
        lqw.eq(CommodityCollection::getUid, uid);
        commodityService.getCCPage(page, lqw);
        return Result.setSuccess(Result.ResultCode.SUCCESS, page.getRecords());
    }

    /**
     * 搜索商品
     *
     * @param pageNum
     * @param count
     * @param condition
     * @return List<Commodity>
     */
    @GetMapping("/search/{pageNum}/{count}/{condition}")
    public Result search(@PathVariable int pageNum, @PathVariable int count,
                         @PathVariable String condition) {
        if (pageNum < 0 || count <= 0) {
            return Result.setError(Result.ResultCode.PARAM_ERROR);
        }

        IPage<Commodity> page = new Page<>(pageNum, count);
        LambdaQueryWrapper<Commodity> lqw = new LambdaQueryWrapper<>();
        lqw.eq(Commodity::getStatus, 0)
                .like(Strings.isNotEmpty(condition),
                        Commodity::getCommodityTitle, condition);
        commodityService.page(page, lqw);
        return Result.setSuccess(Result.ResultCode.SUCCESS, page.getRecords());
    }

    /**
     * 查看商品详情（已废弃）
     *
     * @param uid
     * @param cid
     * @return map<string, object> 商品详细对象、店铺对象、isColl（是否收藏）、isSub（是否订阅店铺）
     */
    @GetMapping("/getcd/{uid}/{cid}")
    public Result getCD(@PathVariable int uid, @PathVariable int cid)
            throws JsonProcessingException {
        Map<String, Object> data = new HashMap<>();
        CommodityDetail cd = commodityService.selectCDById(cid);
        Commodity commodity = commodityService.getById(cid);
        if (cd != null && commodity != null) {
            Shop shop = shopService.selectById(commodity.getSid());
            if (shop != null) {
                //判断是否订阅
                LambdaQueryWrapper<ShopSubscription> lqw_ss = new LambdaQueryWrapper<>();
                lqw_ss.eq(ShopSubscription::getUid, uid)
                        .eq(ShopSubscription::getSid, shop.getSid());
                boolean isSub = shopService.isSub(lqw_ss);

                //判断是否收藏
                LambdaQueryWrapper<CommodityCollection> lqw_cc = new LambdaQueryWrapper<>();
                lqw_cc.eq(CommodityCollection::getUid, uid)
                        .eq(CommodityCollection::getCid, commodity.getCid());
                boolean isColl = commodityService.isColl(lqw_cc);

                data.put("cd", cd);
                data.put("shop", shop);
                data.put("isColl", isColl);
                data.put("isSub", isSub);

                return Result.setSuccess(Result.ResultCode.SUCCESS, data);
            }
        }
        return Result.setError(Result.ResultCode.INFO_NOTFOUND);
    }

    /**
     * 查看商品详情
     *
     * @param cid
     * @return CommodityDetail
     */
    @GetMapping("/getcd/{cid}")
    public Result getCD(@PathVariable int cid) throws JsonProcessingException {
        return Result.setSuccess(Result.ResultCode.SUCCESS,
                commodityService.selectCDById(cid));
    }

    /**
     * 获取商品主图
     *
     * @param cid
     * @param response
     * @return
     */
    @GetMapping("/getimg/{cid}")
    public Result getImg(@PathVariable int cid, HttpServletResponse response) {
        Commodity commodity = commodityService.getById(cid);
        if (commodity != null) {
            String fileName = commodity.getCommodityImg();
            if (fileName == null){ //图片不存在
                return Result.setError(Result.ResultCode.IMG_NOTFOUND);
            }

            String filePath = FileUtils.getFilePath_commodity(fileName);
            File file = new File(filePath);
            if (!file.exists()) {
                return Result.setError(Result.ResultCode.IMG_NOTFOUND);
            }

            FileInputStream fis = null;
            OutputStream os = null;
            response.setCharacterEncoding("utf-8");
            response.setContentType(FileUtils.getContentType(fileName));
            try {
                fis = new FileInputStream(filePath);
                os = response.getOutputStream();
                int length = 0;
                byte[] buffer = new byte[1024 * 10];
                while ((length = fis.read(buffer)) != -1) {
                    os.write(buffer, 0, length);
                }
            } catch (Exception e) {
                log.error(e.getMessage());
                return Result.setError(Result.ResultCode.NETWORK_ERROR);
            } finally {
                if (fis != null) {
                    try {
                        fis.close();
                    } catch (IOException e) {
                        log.error(e.getMessage());
                    }
                }

                if (os != null) {
                    try {
                        os.close();
                    } catch (IOException e) {
                        log.error(e.getMessage());
                    }
                }
            }
        } else { //商品不存在
            return Result.setError(Result.ResultCode.COMMODITY_NOTFOUND);
        }
        return null;    //正常则返回null，防止二次调用response输出流
    }
}
