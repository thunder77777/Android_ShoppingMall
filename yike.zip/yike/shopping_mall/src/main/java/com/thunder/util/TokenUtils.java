package com.thunder.util;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTCreationException;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.auth0.jwt.interfaces.JWTVerifier;
import com.thunder.pojo.User;

public class TokenUtils {
    //密钥盐
    private static final String TOKEN_SECRET = "ljdyaishijin**3nkjnj??";

    /**
     * 生成token
     *
     * @param user
     * @return
     */
    public static String sign(User user) {
        String token = null;
        try {
            token = JWT.create()
                    //存放数据
                    .withClaim("uid", user.getUid())
                    .sign(Algorithm.HMAC256(TOKEN_SECRET));
        } catch (IllegalArgumentException | JWTCreationException je) {

        }
        return token;
    }

    /**
     * token验证
     *
     * @param token
     * @return
     */
    public static Boolean verify(String token) {
        try {
            //创建token验证器
            JWTVerifier jwtVerifier = JWT.require(Algorithm.HMAC256(TOKEN_SECRET)).build();
            DecodedJWT decodedJWT = jwtVerifier.verify(token);
            System.out.println("认证通过：");
            System.out.println("uid: " + decodedJWT.getClaim("uid").asString());
        } catch (IllegalArgumentException | JWTVerificationException e) {
            //抛出错误即为验证不通过
            return false;
        }
        return true;
    }

    /**
     * 获取uid
     *
     * @param token
     * @return
     */
    public static Integer getUid(String token){
        try {
            //创建token验证器
            JWTVerifier jwtVerifier = JWT.require(Algorithm.HMAC256(TOKEN_SECRET)).build();
            DecodedJWT decodedJWT = jwtVerifier.verify(token);
            return decodedJWT.getClaim("uid").asInt();
        } catch (IllegalArgumentException | JWTVerificationException e) {
            return null;
        }
    }
}
