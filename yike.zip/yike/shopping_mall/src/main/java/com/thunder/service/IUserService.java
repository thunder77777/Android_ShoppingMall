package com.thunder.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.thunder.pojo.User;

public interface IUserService extends IService<User> {
}
