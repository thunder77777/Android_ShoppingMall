package com.thunder.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.thunder.mapper.OrderDetailMapper;
import com.thunder.mapper.OrderMapper;
import com.thunder.pojo.Order;
import com.thunder.pojo.OrderDetail;
import com.thunder.service.IOrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Service;

@Service
@PropertySource("classpath:yike.properties")
public class OrderServiceImpl extends ServiceImpl<OrderMapper, Order>
        implements IOrderService {

    @Autowired
    private OrderDetailMapper orderDetailMapper;

    @Override
    public boolean save_orderDetail(OrderDetail orderDetail) {
        return orderDetailMapper.insert(orderDetail) > 0;
    }

    @Override
    public OrderDetail getOneDetail(int oid) {
        return orderDetailMapper.selectById(oid);
    }
}
