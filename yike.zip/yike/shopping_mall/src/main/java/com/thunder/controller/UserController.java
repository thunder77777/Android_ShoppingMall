package com.thunder.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.thunder.pojo.Result;
import com.thunder.pojo.User;
import com.thunder.service.IUserService;
import com.thunder.util.FileUtils;
import com.thunder.util.TokenUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

@RestController
@Slf4j
@ResponseBody
@Transactional
@RequestMapping("/users")
@PropertySource("classpath:yike.properties")
public class UserController {
    @Autowired
    private IUserService userService;

    @Autowired
    private StringRedisTemplate redisTemplate;

    @Value("${expirationTime}")
    private int expirationTime; //登入过期时间（从配置文件中获取）

    @Value("${tokenKey}")
    private String tokenKey;

    /**
     * 注册功能
     * 1.验证phone/email不为空
     * 2.验证phone/email唯一
     *
     * @param phone
     * @param email
     * @param password
     * @return
     */
    @PostMapping("/register")
    public Result register(@RequestParam String phone, @RequestParam String email
            , @RequestParam String password) {
        //输入参数不能为空
        if (phone == null || email == null || password == null) {
            return Result.setError(Result.ResultCode.PARAM_ERROR);
        }
        //phone/email必须唯一
        LambdaQueryWrapper<User> lqw = new LambdaQueryWrapper<>();
        lqw.eq(User::getPhone, phone).or().eq(User::getEmail, email);
        if (userService.getOne(lqw) != null) {
            return Result.setError(Result.ResultCode.PARAM_ERROR);
        }

        User user = new User();
        user.setPhone(phone);
        user.setEmail(email);
        user.setPassword(password);
        if (userService.save(user)) {
            return Result.setSuccess(Result.ResultCode.SUCCESS, null);
        }
        return Result.setError(Result.ResultCode.DATABASE_STORAGE_ERROR);
    }

    /**
     * 登入功能
     * 1.验证用户是否存在
     * 2.生成token、存入redis
     * 3.返回user、token
     *
     * @param account
     * @param password
     * @return
     */
    @GetMapping("/login/{account}/{password}")
    public Result login(@PathVariable String account, @PathVariable String password) {
        Map<String, Object> data = new HashMap<>();
        LambdaQueryWrapper<User> lqw = new LambdaQueryWrapper<>();
        lqw.eq(Strings.isNotEmpty(account), User::getPhone, account).or()
                .eq(Strings.isNotEmpty(account), User::getEmail, account)
                .eq(Strings.isNotEmpty(password), User::getPassword, password);
        User user = userService.getOne(lqw);
        if (user != null) {
            String token = TokenUtils.sign(user);
            data.put("user", user);
            data.put("token", token);
            redisTemplate.opsForValue()
                    .set(tokenKey + user.getUid(), token,
                            expirationTime, TimeUnit.MINUTES);
        } else {
            return Result.setError(Result.ResultCode.USER_NOTFOUND);
        }
        return Result.setSuccess(Result.ResultCode.SUCCESS, data);
    }

    /**
     * 更改用户个人信息
     *
     * @param user
     * @return
     */
    @PutMapping("/changeInfo")
    public Result changeInfo(@RequestBody User user) {
        LambdaUpdateWrapper<User> luw = new LambdaUpdateWrapper<>();
        luw.eq(User::getUid, user.getUid())
                .set(Strings.isNotEmpty(user.getName()), User::getName, user.getName())
                .set(user.getSex() == 0 || user.getSex() == 1,
                        User::getSex, user.getSex())
                .set(Strings.isNotEmpty(user.getSignature()), User::getSignature,
                        user.getSignature());
        if (userService.update(luw)) {
            return Result.setSuccess(Result.ResultCode.SUCCESS, null);
        }
        return Result.setError(Result.ResultCode.PARAM_ERROR);
    }

    /**
     * 修改密码
     * 1.验证新老密码是否不同
     * 2.验证原密码是否正确
     *
     * @param uid
     * @param pwd_old
     * @param pwd_new
     * @return
     */
    @PutMapping("/changepwd")
    public Result changePwd(@RequestParam int uid, @RequestParam String pwd_old,
                            @RequestParam String pwd_new) {
        if (pwd_old == null || pwd_new == null || pwd_old.equals(pwd_new)) {
            return Result.setError(Result.ResultCode.PARAM_ERROR);
        } else {
            LambdaQueryWrapper<User> lqw = new LambdaQueryWrapper<>();
            lqw.eq(User::getUid, uid).eq(User::getPassword, pwd_old);
            if (userService.getOne(lqw) == null) {
                return Result.setError(Result.ResultCode.USER_NOTFOUND);
            }
        }

        LambdaUpdateWrapper<User> luw = new LambdaUpdateWrapper<>();
        luw.eq(User::getUid, uid)
                .set(User::getPassword, pwd_new);
        if (userService.update(luw)) {
            return Result.setSuccess(Result.ResultCode.SUCCESS, null);
        }
        return Result.setError(Result.ResultCode.DATABASE_STORAGE_ERROR);
    }

    /**
     * 上传用户头像
     *
     * @param file
     * @param uid
     * @return flag
     */
    @PostMapping("/uploadimg")
    public Result uploadImg(@RequestParam MultipartFile file, @RequestParam int uid)
            throws IOException {
        if (file != null) {
            if (FileUtils.checkType(file)) {
                if (FileUtils.checkSize(file)) {
                    User user = userService.getById(uid);
                    if (user != null) {
                        //原来的头像
                        String img_old = user.getHeadImg();

                        String fileName = FileUtils.getFileName(file, uid);
                        String filePath = FileUtils.getFilePath_user(fileName);
                        file.transferTo(new File(filePath));
                        LambdaUpdateWrapper<User> luw = new LambdaUpdateWrapper<>();
                        luw.eq(User::getUid, uid)
                                .set(User::getHeadImg, fileName);
                        if (userService.update(luw)) {
                            //上传成功则删除原来的头像
                            if(img_old != null){
                                File delFile = new File(FileUtils.getFilePath_user(img_old));
                                if (delFile.exists()){
                                    delFile.delete();
                                }
                            }
                            return Result.setSuccess(Result.ResultCode.SUCCESS, null);
                        }
                        return Result.setError(Result.ResultCode.DATABASE_STORAGE_ERROR);
                    }
                    return Result.setError(Result.ResultCode.USER_NOTFOUND);
                }
                return Result.setError(Result.ResultCode.IMG_SIZE_ERROR);
            }
            return Result.setError(Result.ResultCode.IMG_TYPE_ERROR);
        }
        return Result.setError(Result.ResultCode.PARAM_ERROR);
    }

    /**
     * 获取用户头像
     *
     * @param uid
     * @param response
     * @return
     */
    @GetMapping("/getimg/{uid}")
    public Result getImg(@PathVariable int uid, HttpServletResponse response) {
        User user = userService.getById(uid);
        if (user != null) {
            String fileName = user.getHeadImg();
            if(fileName != null){
                String filePath = FileUtils.getFilePath_user(fileName);
                File file = new File(filePath);
                if (!file.exists()) {
                    return Result.setError(Result.ResultCode.IMG_NOTFOUND);
                }

                response.setContentType(FileUtils.getContentType(fileName));
                FileInputStream fis = null;
                OutputStream os = null;
                try {
                    fis = new FileInputStream(filePath);
                    os = response.getOutputStream();
                    int length = 0;
                    byte[] buffer = new byte[1024 * 10];
                    while ((length = fis.read(buffer)) != -1) {
                        os.write(buffer, 0, length);
                    }
                } catch (Exception e) {
                    log.error(e.getMessage());
                    return Result.setError(Result.ResultCode.NETWORK_ERROR);
                } finally {
                    if (fis != null) {
                        try {
                            fis.close();
                        } catch (IOException e) {
                            log.error(e.getMessage());
                            return Result.setError(Result.ResultCode.NETWORK_ERROR);
                        }
                    }
                    if (os != null) {
                        try {
                            os.close();
                        } catch (IOException e) {
                            log.error(e.getMessage());
                            return Result.setError(Result.ResultCode.NETWORK_ERROR);
                        }
                    }
                }
                return null;
            }
            return Result.setError(Result.ResultCode.IMG_NOTFOUND);
        } else {
            return Result.setError(Result.ResultCode.USER_NOTFOUND);
        }
    }

    /**
     * 设置用户昵称（废弃）
     *
     * @param uid 用户id
     * @param name 用户昵称
     * @return flag
     */
    /*@PutMapping("/setname")
    public Result setName(@RequestParam int uid, @RequestParam String name){
        LambdaUpdateWrapper<User> luw = new LambdaUpdateWrapper<>();
        luw.eq(User::getUid, uid)
                .set(User::getName, name);
        if (userService.update(luw)) {
            return Result.setSuccess(Result.ResultCode.SUCCESS, null);
        }
        return Result.setError(Result.ResultCode.DATABASE_STORAGE_ERROR);
    }*/

    /**
     * 测试 loacldate
     *
     * @param localDate
     * @return
     */
    @PostMapping("/test")
    public Result testDate(@RequestBody LocalDate localDate){
        return Result.setSuccess(Result.ResultCode.SUCCESS, localDate);
    }
}
