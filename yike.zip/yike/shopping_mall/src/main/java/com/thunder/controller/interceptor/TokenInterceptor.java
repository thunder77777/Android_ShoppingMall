package com.thunder.controller.interceptor;

import com.thunder.pojo.Result;
import com.thunder.util.JSONUtils;
import com.thunder.util.TokenUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Component
@PropertySource("classpath:yike.properties")
public class TokenInterceptor implements HandlerInterceptor {
    @Autowired
    private StringRedisTemplate redisTemplate;

    @Value("${tokenKey}")
    private String tokenKey;

    @Override
    public boolean preHandle(HttpServletRequest request,
                             HttpServletResponse response,
                             Object handler) throws Exception {
        response.setContentType("application/json; charset=utf-8");

        //跨域请求会首先发一个option请求，直接返回正常状态并通过拦截器
        if (request.getMethod().equals("OPTIONS")) {
            response.setStatus(HttpServletResponse.SC_OK);
            return true;
        }

        //验证token
        String token = request.getHeader("token");
        if (token != null) {
            Integer uid = TokenUtils.getUid(token);
            if (uid != null) {
                String token_redis = redisTemplate.opsForValue().get(tokenKey + uid);
                if (token.equals(token_redis)) {
                    return true;
                }else { //用户登入过期
                    response.getWriter().write
                            (JSONUtils.toJSON(Result.setError(Result.ResultCode.LOGIN_TIMEOUT)));
                    return false;
                }
            }
        }
        response.getWriter().write
                (JSONUtils.toJSON(Result.setError(Result.ResultCode.NOT_LOGIN)));
        return false;
    }
}
