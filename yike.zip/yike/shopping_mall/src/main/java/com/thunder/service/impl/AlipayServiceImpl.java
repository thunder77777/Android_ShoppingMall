package com.thunder.service.impl;

import com.thunder.service.IAlipayService;
import com.thunder.util.OrderInfoUtil2_0;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
@PropertySource("classpath:yike.properties")
public class AlipayServiceImpl implements IAlipayService {

    /**
     * 用于支付宝支付业务的入参 app_id。
     */
    @Value("${appid}")
    private String APPID;

    /**
     * 用于支付宝账户登录授权业务的入参 pid。
     */
    @Value("${pid}")
    private String PID = "2088621959278078";

    /**
     * 用于支付宝账户登录授权业务的入参 target_id。
     */
    @Value("${targetId}")
    private String TARGET_ID = "fgiesa6677@sandbox.com";

    /**
     *  pkcs8 格式的商户私钥。
     *
     * 	如下私钥，RSA2_PRIVATE 或者 RSA_PRIVATE 只需要填入一个，如果两个都设置了，本 Demo 将优先
     * 	使用 RSA2_PRIVATE。RSA2_PRIVATE 可以保证商户交易在更加安全的环境下进行，建议商户使用
     * 	RSA2_PRIVATE。
     *
     * 	建议使用支付宝提供的公私钥生成工具生成和获取 RSA2_PRIVATE。
     * 	工具地址：https://doc.open.alipay.com/docs/doc.htm?treeId=291&articleId=106097&docType=1
     */
    @Value("${privateKey}")
    private String RSA2_PRIVATE = "MIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQCFnhyjgCLvBVt4QErgizhVm6eKK/0lTICzD/QfJ05eu5RnERj+2D824/kHGjab8p6ttKBS0oBSm4eXIY7e01ps1CiCSiomH8aoAd082BP2F/ef7sLjM/iWOfbceQvOz5hGG77IPyayn4EHdhvRPZIIgRZ2F9oBCEIqne2T73qfjeXfudoJszTIjRqXUEYphsV2noBmNadRtMdEtsCGEDyT+E6Sbe7nuWgI5fTI8vDPzPzuMPingS84rt+ZrwLdr7U1vmbCe6o4shJdfJ98Rcyzckh3v5QjBJvd+wguLfq96UdIR5v0yi9uwsbqWz1kAn6K59ce7v98xbEp4En4HM1VAgMBAAECggEASYcYe2Cn2KA6FZJLogT6myFssLxEMaJHsEG3NO2MUtUmdRETkCmvn6UUBLSIGIkKiMw87VapBsxPcPsmg7gKqpiVMh1d1FzoFMvx0umVEndd7MSWujB/OyvqjKiPtt7GDM53zfnycZkUh+aWqC4ZjlR658F4VdkVkB4X/rBp6iJ+rwWb20FU5EP2fk1m873dD9t+cpgukuhb61/uWh5BZNho3hfTKi9u+pTnLL5Q5tI9XxTBGnl5Cjxt2XSDPq0mlRL2rEXs7xnI+re+hrgUxFAxYGLhFJU+Lm2L7A0365iLacaERkuc72qW8jYRQQCfaPg0lgD0bvZzB0Q4EqlqgQKBgQDQ04Maqd3KSE2paysUGfGGgZCzd99CYZHp/w6FdP/s7sgn7ZnjMHgHjEnZU+EMTK0irsx7Z5AkldcVqNvkdN136IY0aI2NqeMux5sjXXNw7T57C54OgcbiFkxbAeMwvwEaGiK2ELaw4JgTugc++iKclsFtrtwT1gmG6gmsM+KoRwKBgQCjzUMp5wJHBouTOqfFP0AsAZmf2t5zK3y2D9oFgEdQTgF8zUGjNjb5+GFDMnm3uhKl4TkaGoACNIWdt8r2+drVej3KxohlUwUB4NXytFque6lQJON/yNWOmFn9LQW06++8fxwqoH/SowLnOq9IwW2fVIWbFUmXCbIn/nsULWNHgwKBgFhs5/wXZ9IrEa+msKQfZDWHkaVdIg2y0R2boiOC6ogCiIDXzKz2Li1MC01ahlY19a5VBENRFClZxaznRs2TauBGduWkTCRrhsadQSUVgjeUTju+LJyJ+ZRsysJSp0hR6P6LiJ09sI5vXBYmVMEnHBbgg2GVhJ1lqb0WRyhDBDwrAoGAFAevpNoYzzKfsrtDdL1NTZRMgt2ywgaZU3IQyQdssQc461f2JM0mX97dlegANlVMnngyEV0YNizSAf1NlnHrLpuqHre0Sh+ixx4FS45+YEPC6of4QdH/O1ap+mmc/wiy4ivw9810k/9XBYuJj64Hh6pARDyQKSYIYRefWVJLh50CgYBoaU3TWNWCN0uJ4osFI+e69hu6VusOSWehS8UjAZO0uiGtzhwm2m5LHJ3R5V979EcNjQxvDSQIwfQMZBw40M75zgKQdmCe6nwyVkP8641oJUlMfdnw0ABuHTT7ST9wJboFZt2IU0tfVq9PuZAtQCdA30GANzaSDKc7FRwsIUXBLQ==";
    public static final String RSA_PRIVATE = "";

    private static final int SDK_PAY_FLAG = 1;
    private static final int SDK_AUTH_FLAG = 2;

    @Value("${subject}")
    private String subject;

    @Override
    public String getOrderInfo(double price) {
        boolean rsa2 = (RSA2_PRIVATE.length() > 0);
        Map<String, String> params = OrderInfoUtil2_0.buildOrderParamMap
                (APPID, price, subject, rsa2);
        String orderParam = OrderInfoUtil2_0.buildOrderParam(params);

        String privateKey = rsa2 ? RSA2_PRIVATE : RSA_PRIVATE;
        String sign = OrderInfoUtil2_0.getSign(params, privateKey, rsa2);
        return orderParam + "&" + sign; //orderInfo
    }
}
