package com.thunder.pojo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

@Data
@TableName("`order`")
public class Order {
    @TableId(type = IdType.AUTO)
    private Integer oid;
    private Integer uid;
    private Integer cid;
    private Integer sid;
    @TableField("commodity_img")
    private String commodityImg;
    @TableField("commodity_title")
    private String commodityTitle;
    @TableField("commodity_price")
    private double commodityPrice;
    private Integer quantity;
    @TableField("total_price")
    private double totalPrice;
    @TableField("shop_title")
    private String shopTitle;
    private Integer status;
}
