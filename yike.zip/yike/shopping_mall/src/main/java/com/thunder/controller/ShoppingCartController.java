package com.thunder.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.thunder.pojo.Commodity;
import com.thunder.pojo.Result;
import com.thunder.pojo.Shop;
import com.thunder.pojo.ShoppingCart;
import com.thunder.pojo.parameter.PurchaseParameter;
import com.thunder.service.ICommodityService;
import com.thunder.service.IShopService;
import com.thunder.service.IShoppingCartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@ResponseBody
@Transactional
@RequestMapping("/carts")
public class ShoppingCartController {

    @Autowired
    private ICommodityService commodityService;

    @Autowired
    private IShopService shopService;

    @Autowired
    private IShoppingCartService shoppingCartService;

    @Autowired
    private OrderController orderController;

    /**
     * 添加购物车
     *
     * @param uid
     * @param cid
     * @param quantity
     * @return flag
     * @throws JsonProcessingException
     */
    @PostMapping("/add")
    public Result add(@RequestParam int uid, @RequestParam int cid,
                      @RequestParam int quantity) throws JsonProcessingException {
        Commodity commodity = commodityService.selectById(cid);
        if (commodity != null) {
            Shop shop = shopService.selectById(commodity.getSid());
            if (shop != null) {
                ShoppingCart shoppingCart = new ShoppingCart();
                shoppingCart.setCid(cid);
                shoppingCart.setCommodityTitle(commodity.getCommodityTitle());
                shoppingCart.setCommodityImg(commodity.getCommodityImg());
                shoppingCart.setCommodityPrice(commodity.getCommodityPrice());
                shoppingCart.setQuantity(quantity);
                shoppingCart.setUid(uid);
                shoppingCart.setSid(shop.getSid());
                shoppingCart.setShopTitle(shop.getShopTitle());

                LambdaQueryWrapper<ShoppingCart> law = new LambdaQueryWrapper<>();
                law.eq(ShoppingCart::getCid, cid)
                        .eq(ShoppingCart::getUid, uid)
                        .eq(ShoppingCart::getSid, shop.getSid());
                if (shoppingCartService.saveOrUpdate(shoppingCart, law)) {
                    return Result.setSuccess(Result.ResultCode.SUCCESS, null);
                } else {
                    return Result.setError(Result.ResultCode.DATABASE_STORAGE_ERROR);
                }
            }
        }
        return Result.setError(Result.ResultCode.INFO_NOTFOUND);
    }

    /**
     * 查看购物车内商品
     *
     * @param uid
     * @param pageNum
     * @param count
     * @return list<ShoppingCart>
     */
    @GetMapping("/getsc/{uid}/{pageNum}/{count}")
    public Result getSC(@PathVariable int uid,
                        @PathVariable int pageNum, @PathVariable int count) {
        if (pageNum < 0 || count <= 0) {
            return Result.setError(Result.ResultCode.PARAM_ERROR);
        }

        IPage<ShoppingCart> page = new Page<>(pageNum, count);
        LambdaQueryWrapper<ShoppingCart> lqw = new LambdaQueryWrapper<>();
        lqw.eq(ShoppingCart::getUid, uid);
        shoppingCartService.page(page, lqw);
        return Result.setSuccess(Result.ResultCode.SUCCESS, page.getRecords());
    }

    /**
     * 清空购物车
     *
     * @param uid
     * @return flag
     */
    @DeleteMapping("/delcart/{uid}")
    public Result delCart(@PathVariable int uid) {
        LambdaUpdateWrapper<ShoppingCart> luw = new LambdaUpdateWrapper<>();
        luw.eq(ShoppingCart::getUid, uid);
        if (shoppingCartService.remove(luw)) {
            return Result.setSuccess(Result.ResultCode.SUCCESS, null);
        }
        return Result.setError(Result.ResultCode.INFO_NOTFOUND);
    }

    /**
     * 删除购物车中某几个商品
     *
     * @param scs 购物车主键集合
     * @return
     */
    @DeleteMapping("/delscs")
    public Result delSCS(@RequestBody List<Integer> scs) {
        if (scs.size() == 0) {
            return Result.setError(Result.ResultCode.PARAM_ERROR);
        }

        LambdaQueryWrapper<ShoppingCart> lqw = new LambdaQueryWrapper<>();
        lqw.in(ShoppingCart::getScid, scs);
        if (shoppingCartService.remove(lqw)) {
            return Result.setSuccess(Result.ResultCode.SUCCESS, null);
        }

        return Result.setError(Result.ResultCode.DATA_DELETE_FAIL);
    }

    /**
     * 选中指定某几个商品结算
     *
     * @param ppList 下单参数集合
     * @return flag
     */
    @PostMapping("/settlement")
    public Result settlement(@RequestBody List<PurchaseParameter> ppList)
            throws JsonProcessingException {
        if (ppList.size() == 0) {
            return Result.setError(Result.ResultCode.PARAM_ERROR);
        }


        LambdaQueryWrapper<ShoppingCart> law = new LambdaQueryWrapper<>();
        for (PurchaseParameter pp : ppList) {
            orderController.purchase(pp);

            //删除购物车内已经结算的商品
            law.clear();
            law.eq(ShoppingCart::getUid, pp.getUid())
                    .eq(ShoppingCart::getCid, pp.getCid())
                    .eq(ShoppingCart::getSid, pp.getSid());
            shoppingCartService.remove(law);
        }
        return Result.setSuccess(Result.ResultCode.SUCCESS, null);
    }

    /**
     * 修改购物车内商品数量
     *
     * @param scid
     * @param quantity
     * @return
     */
    @PutMapping("/setquantity")
    public Result setQuantity(@RequestParam int scid, @RequestParam int quantity) {
        if (quantity <= 0 || quantity >= 100
                || shoppingCartService.getById(scid) == null) {
            return Result.setError(Result.ResultCode.PARAM_ERROR);
        }

        LambdaUpdateWrapper<ShoppingCart> luw = new LambdaUpdateWrapper<>();
        luw.eq(ShoppingCart::getScid, scid)
                .set(ShoppingCart::getQuantity, quantity);
        if (shoppingCartService.update(luw)) {
            return Result.setSuccess(Result.ResultCode.SUCCESS, null);
        }
        return Result.setError(Result.ResultCode.DATABASE_STORAGE_ERROR);
    }
}
