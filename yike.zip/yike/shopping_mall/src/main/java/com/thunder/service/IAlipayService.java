package com.thunder.service;

public interface IAlipayService {
    String getOrderInfo(double price);
}
