package com.thunder.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.thunder.mapper.UserMapper;
import com.thunder.pojo.User;
import com.thunder.service.IUserService;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements IUserService {
}
