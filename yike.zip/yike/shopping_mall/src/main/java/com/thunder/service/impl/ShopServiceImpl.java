package com.thunder.service.impl;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.thunder.mapper.ShopMapper;
import com.thunder.mapper.ShopSubscriptionMapper;
import com.thunder.pojo.Shop;
import com.thunder.pojo.ShopSubscription;
import com.thunder.service.IShopService;
import com.thunder.util.JSONUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

@Service
@PropertySource("classpath:yike.properties")
public class ShopServiceImpl extends ServiceImpl<ShopMapper, Shop>
        implements IShopService {

    @Autowired
    private ShopMapper shopMapper;

    @Autowired
    private ShopSubscriptionMapper ssMapper;

    @Autowired
    private StringRedisTemplate redisTemplate;

    @Value("${shopKey}")
    private String shopKey;

    @Override
    public Shop selectById(int sid) throws JsonProcessingException {
        String shop_json = redisTemplate.opsForValue().get(shopKey + sid);
        if (shop_json != null) {
            return (Shop) JSONUtils.toObject(shop_json, Shop.class);
        }

        //redis中不存在店铺对象，则从数据库中查找
        Shop shop = shopMapper.selectById(sid);
        redisTemplate.opsForValue().set(shopKey + sid, JSONUtils.toJSON(shop));
        return shop;
    }

    /**
     * 获取店铺订阅表
     *
     * @param page
     * @param queryWrapper
     * @return
     */
    @Override
    public IPage<ShopSubscription> getSSPage(IPage<ShopSubscription> page,
                                             Wrapper<ShopSubscription> queryWrapper) {
        return ssMapper.selectPage(page, queryWrapper);
    }

    @Override
    public boolean isSub(Wrapper<ShopSubscription> queryWrapper) {
        return ssMapper.selectOne(queryWrapper) != null;
    }

    @Override
    public boolean insertSS(ShopSubscription ss) {
        return ssMapper.insert(ss) > 0;
    }
}
