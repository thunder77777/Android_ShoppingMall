package com.thunder.pojo.parameter;

import lombok.Data;

/**
 * 添加商品参数
 */
@Data
public class CommodityParameter {
    private int uid;
    private int sid;
    private String commodityTitle;
    private double commodityPrice;
    private int stock;
}
