package com.thunder.pojo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

@Data
@TableName("commodity")
public class Commodity {
    @TableId(type = IdType.AUTO)
    private Integer cid;
    private Integer sid;
    @TableField("commodity_title")
    private String commodityTitle;
    @TableField("commodity_img")
    private String commodityImg;
    @TableField("commodity_price")
    private double commodityPrice;
    private Integer status;
}
