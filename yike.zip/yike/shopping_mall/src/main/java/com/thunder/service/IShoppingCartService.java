package com.thunder.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.thunder.pojo.ShoppingCart;

public interface IShoppingCartService extends IService<ShoppingCart> {
}
