package com.thunder.pojo;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
public class Result {
    private Boolean flag;
    private Integer code;
    private String msg;
    private Object data;

    public void setSuccess(String msg, Object data) {
        this.code = 200;
        this.msg = "success-" + msg;
        this.data = data;
    }

    public static Result setSuccess(ResultCode resultCode, Object data) {
        Result r = new Result();
        r.setFlag(resultCode.getFlag());
        r.setCode(resultCode.getCode());
        r.setMsg(resultCode.getMessage());
        r.setData(data);
        return r;
    }

    public static Result setError(ResultCode resultCode) {
        Result r = new Result();
        r.setFlag(resultCode.getFlag());
        r.setCode(resultCode.getCode());
        r.setMsg(resultCode.getMessage());
        return r;
    }

    public void setInfo(String msg, Object data) {
        this.code = 500;
        this.msg = "warning-" + msg;
        this.data = data;
    }

    @Getter
    public enum ResultCode {
        SUCCESS(true, 200, "成功"),
        USER_NOTFOUND(false, 400, "用户不存在"),
        NOT_LOGIN(false, 401, "用户未登入"),
        LOGIN_TIMEOUT(false, 402, "登入过期"),
        SHOP_NOTFOUND(false, 403, "店铺不存在"),
        COMMODITY_NOTFOUND(false, 403, "商品不存在"),
        UNKNOWN_REASON(false, 500, "未知错误"),
        BAD_SQL_GRAMMAR(false, 501, "sql语法错误"),
        JSON_PARSE_ERROR(false, 502, "json解析异常"),
        PARAM_ERROR(false, 503, "参数错误"),
        PARAM_TYPE_MISMATCH(false, 504, "参数类型不匹配"),
        PARAM_MISSING(false, 505, "缺少必要参数"),
        FILE_UPLOAD_ERROR(false, 506, "文件上传错误"),
        EXCEL_DATA_IMPORT_ERROR(false, 507, "Excel数据导入错误"),
        DATABASE_STORAGE_ERROR(false, 508, "数据存储错误"),
        INFO_NOTFOUND(false, 509, "所查数据不存在"),
        DATA_DELETE_FAIL(false, 510, "数据删除失败"),
        SHOP_TITLE_DUPLICATED(false, 511, "店铺名称重复"),
        IMG_TYPE_ERROR(false, 512, "图片格式不支持"),
        IMG_SIZE_ERROR(false, 513, "图片过大"),
        IMG_UPLOAD_ERROR(false, 514, "图片上传错误"),
        IMG_NOTFOUND(false, 515, "图片不存在"),
        NETWORK_ERROR(false, 516, "网络错误");

        private final Boolean flag;
        private final Integer code;
        private final String message;

        ResultCode(Boolean flag, Integer code, String message) {
            this.flag = flag;
            this.code = code;
            this.message = message;
        }
    }
}
