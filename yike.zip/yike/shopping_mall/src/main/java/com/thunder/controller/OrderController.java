package com.thunder.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.thunder.pojo.*;
import com.thunder.pojo.parameter.PurchaseParameter;
import com.thunder.service.IAlipayService;
import com.thunder.service.ICommodityService;
import com.thunder.service.IOrderService;
import com.thunder.service.IShopService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;

@RestController
@ResponseBody
@Transactional
@RequestMapping("/orders")
public class OrderController {
    @Autowired
    private IShopService shopService;

    @Autowired
    private ICommodityService commodityService;

    @Autowired
    private IOrderService orderService;

    @Autowired
    private IAlipayService alipayService;

    /**
     * 下单
     *
     * @param pp 下单参数对象
     * @return flag
     * @throws JsonProcessingException
     */
    @PostMapping("/purchase")
    public Result purchase(@RequestBody PurchaseParameter pp)
            throws JsonProcessingException {

        if (pp == null || pp.getQuantity() <= 0 || pp.getQuantity() >= 100
                || pp.getPayment() < 0 || pp.getPayment() > 1) {
            return Result.setError(Result.ResultCode.PARAM_ERROR);
        }

        //参数判断
        LambdaQueryWrapper<Commodity> luw = new LambdaQueryWrapper<>();
        luw.eq(Commodity::getCid, pp.getCid())
                .eq(Commodity::getSid, pp.getSid());
        Commodity commodity = commodityService.getOne(luw);
        Shop shop = shopService.selectById(pp.getSid());
        if (shop == null || commodity == null) {
            return Result.setError(Result.ResultCode.PARAM_ERROR);
        }

        Order order = new Order();
        OrderDetail orderDetail = new OrderDetail();
        order.setCommodityPrice(commodity.getCommodityPrice());
        order.setCid(commodity.getCid());
        order.setQuantity(pp.getQuantity());
        order.setCommodityTitle(commodity.getCommodityTitle());
        order.setCommodityImg(commodity.getCommodityImg());
        order.setSid(shop.getSid());
        order.setShopTitle(shop.getShopTitle());
        order.setUid(pp.getUid());
        order.setTotalPrice(commodity.getCommodityPrice() * pp.getQuantity());
        if (!orderService.save(order) || order.getOid() == null) {
            return Result.setError(Result.ResultCode.DATABASE_STORAGE_ERROR);
        }

        orderDetail.setBuid(shop.getBuid());
        orderDetail.setOid(order.getOid());
        orderDetail.setPayment(pp.getPayment());
        orderDetail.setPaymentTime(LocalDateTime.now());
        if (!orderService.save_orderDetail(orderDetail) || orderDetail.getSubOid() == null) {
            return Result.setError(Result.ResultCode.DATABASE_STORAGE_ERROR);
        }

        return Result.setSuccess(Result.ResultCode.SUCCESS, null);
    }

    /**
     * 确认收货
     *
     * @param oid
     * @return
     */
    @PutMapping("/receiving")
    public Result receiving(@RequestParam int oid) {
        LambdaUpdateWrapper<Order> luw = new LambdaUpdateWrapper<>();
        luw.eq(Order::getOid, oid)
                .set(Order::getStatus, 2);
        if (orderService.update(null, luw)) {
            return Result.setSuccess(Result.ResultCode.SUCCESS, null);
        }
        return Result.setError(Result.ResultCode.DATABASE_STORAGE_ERROR);
    }

    /**
     * 申请售后
     *
     * @param oid
     * @return
     */
    @PutMapping("/close")
    public Result close(@RequestParam int oid) {
        LambdaUpdateWrapper<Order> luw = new LambdaUpdateWrapper<>();
        luw.eq(Order::getOid, oid)
                .set(Order::getStatus, 3);
        if (orderService.update(null, luw)) {
            return Result.setSuccess(Result.ResultCode.SUCCESS, null);
        }
        return Result.setError(Result.ResultCode.DATABASE_STORAGE_ERROR);
    }

    /**
     * 查看订单
     *
     * @param uid
     * @return list<Order>
     */
    @GetMapping("/getorders/{uid}")
    public Result getOrders(@PathVariable int uid) {
        LambdaQueryWrapper<Order> lqw = new LambdaQueryWrapper();
        lqw.eq(Order::getUid, uid);
        return Result.setSuccess(Result.ResultCode.SUCCESS, orderService.list(lqw));
    }

    /**
     * 查看订单详情
     *
     * @param oid
     * @return OrderDetail
     */
    @GetMapping("/getdetail/{oid}")
    public Result getDetail(@PathVariable int oid) {
        return Result.setSuccess(Result.ResultCode.SUCCESS, orderService.getOneDetail(oid));
    }

    /**
     * 获取orderStr（支付宝信息）
     *
     * @return
     */
    @GetMapping("/getinfo/{price}")
    public Result getOrderInfo(@PathVariable double price){
        String orderInfo = alipayService.getOrderInfo(price);
        return Result.setSuccess(Result.ResultCode.SUCCESS, orderInfo);
    }
}
