package com.thunder.service;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.thunder.pojo.Shop;
import com.thunder.pojo.ShopSubscription;

public interface IShopService extends IService<Shop> {
    Shop selectById(int sid) throws JsonProcessingException;

    /**
     * 获取店铺订阅表
     *
     * @param page
     * @param queryWrapper
     * @return
     */
    IPage<ShopSubscription> getSSPage(IPage<ShopSubscription> page,
                                      Wrapper<ShopSubscription> queryWrapper);

    /**
     * 用户是否订阅该店铺
     *
     * @param queryWrapper
     * @return
     */
    boolean isSub(Wrapper<ShopSubscription> queryWrapper);

    /**
     * 订阅店铺
     *
     * @param ss
     * @return
     */
    boolean insertSS(ShopSubscription ss);
}
