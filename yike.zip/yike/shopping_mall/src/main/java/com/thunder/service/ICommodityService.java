package com.thunder.service;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.thunder.pojo.Commodity;
import com.thunder.pojo.CommodityCollection;
import com.thunder.pojo.CommodityDetail;

public interface ICommodityService extends IService<Commodity> {
    Commodity selectById(int cid) throws JsonProcessingException;

    boolean collect(CommodityCollection commodityCollection);

    /**
     * 查看商品收藏表
     *
     * @param page
     * @param queryWrapper
     * @return
     */
    IPage<CommodityCollection> getCCPage(IPage<CommodityCollection> page,
                                         Wrapper<CommodityCollection> queryWrapper);

    CommodityDetail selectCDById(int cid) throws JsonProcessingException;

    /**
     * 用户是否收藏该商品
     *
     * @param queryWrapper
     * @return
     */
    boolean isColl(Wrapper<CommodityCollection> queryWrapper);

    /**
     * 添加新商品
     *
     * @param cd
     * @return
     */
    boolean insertCD(CommodityDetail cd);
}
